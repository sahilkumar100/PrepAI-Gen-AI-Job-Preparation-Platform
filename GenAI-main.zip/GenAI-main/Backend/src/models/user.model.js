const mongoose = require ('mongoose')


const userSchema=new mongoose.Schema({
    username:{
        type:String,
        unique:[true,"user already exist"],
        required:true,
    },

    email:{
        type:String,
        
        unique:[true,"Account exist with current email add"],
    required:true,
    },
    password:{
        type:String,
        required:true
    }

})


const userModel= mongoose.model("users",userSchema)

module.exports=userModel